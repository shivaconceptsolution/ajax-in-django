from django.shortcuts import render
from .models import Reg
from django.http import HttpResponse
def index(request):
	return render(request,"frontapp/index.html")

def reg(request):

	return render(request,"frontapp/reg.html")

def regcode(request):
	r = Reg(uname=request.POST.get("uid"),pwd=request.POST.get("upass"),email=request.POST.get("email"),mobile=request.POST.get("mobile"))
	r.save()
	return HttpResponse("data inserted successfully")
def checkreg(request):
    r = Reg.objects.filter(uname=request.POST.get("d"))
    if r.count()>0:
    	return HttpResponse("data already exist")
    else:
         return HttpResponse("data not exist")		