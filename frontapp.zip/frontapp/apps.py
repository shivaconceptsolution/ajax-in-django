from django.apps import AppConfig


class FrontappConfig(AppConfig):
    name = 'frontapp'
